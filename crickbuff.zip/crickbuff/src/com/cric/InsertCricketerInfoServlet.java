package com.cric;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.cricbuff.db.CricketDBConnection;

/**
 * Servlet implementation class CricketServlet
 */
@WebServlet("/insertServlet")
@MultipartConfig
public class InsertCricketerInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection con = null;
	static PreparedStatement pst = null;
	static Scanner scanner = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String country = request.getParameter("country");
		String playerType = request.getParameter("playerType");
		int odi = Integer.parseInt(request.getParameter("noofodimatches"));
		double totalScore = Integer.parseInt(request.getParameter("totalscoreinodi"));
		int highestScore = Integer.parseInt(request.getParameter("bestscore"));
		double noOfBallsFaced = Integer.parseInt(request.getParameter("ballsfaced"));
		double noOfBallsBowled = Integer.parseInt(request.getParameter("ballsbowled"));
		int highestWickets = Integer.parseInt(request.getParameter("highestwickets"));
		int totalWickets = Integer.parseInt(request.getParameter("totalwickets"));

		Part photo = request.getPart("pic");

		double avg = (totalScore / odi);

		Random random = new Random();
		double economy = (random.nextInt(9));
		System.out.println(economy);
		double strikeRate = ((totalScore / noOfBallsFaced) * 100.00);
		
		try {
			con = CricketDBConnection.getCricketDbConnection();
			String sql = "insert into cricketer_tbl values(?,?,?,?,?,?,?,?,?,?,?,trunc(" + economy + ",2),?,trunc("
					+ strikeRate + ",2),?)";
			pst = con.prepareStatement(sql);
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, country);
			pst.setString(4, playerType);
			pst.setInt(5, odi);
			pst.setDouble(6, totalScore);
			pst.setDouble(7, highestScore);
			pst.setDouble(8, noOfBallsFaced);
			pst.setDouble(9, noOfBallsBowled);
			pst.setInt(10, highestWickets);
			pst.setInt(11, totalWickets);
			pst.setDouble(12, avg);
			// pst.setDouble(13, economy);
			// pst.setDouble(14, strikeRate);
			pst.setBinaryStream(13, photo.getInputStream(), (int) photo.getSize());
			int insertion = pst.executeUpdate();
			if (insertion > 0) {
				response.sendRedirect("insertmsg.jsp?insertion=" + insertion);
			} else {
				response.sendRedirect("registrationForm.html");
			}
			con.commit();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
