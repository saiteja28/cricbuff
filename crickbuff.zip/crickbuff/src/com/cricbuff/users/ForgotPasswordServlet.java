package com.cricbuff.users;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cricbuff.db.CricketDBConnection;

/**
 * Servlet implementation class ForgotPasswordServlet
 */
@WebServlet("/ForgotPasswordServlet")
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ForgotPasswordServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	static String email;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		email = request.getParameter("emailid");
		try {
			con = CricketDBConnection.getCricketDbConnection();
			pst = con.prepareStatement("select email_id from user_info where email_id= '" + email + "'");
			rs = pst.executeQuery();
			if (rs.next()) {
				if (rs.getString("email_id").equals(email)) {
					response.sendRedirect("setpwd.html");
				} else {
					response.sendRedirect("forgotpwd.html");
				}
			} else {
				response.sendRedirect("forgotpwd.html");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
