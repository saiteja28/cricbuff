package com.cric;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cricbuff.db.CricketDBConnection;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/updateServlet")
public class UpdateCricketerInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int score;
	int wickets;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("servlet");
		int id = Integer.parseInt(request.getParameter("id"));
		int totalScore = Integer.parseInt(request.getParameter("totalscoreinodi"));
		int ballsFaced = Integer.parseInt(request.getParameter("ballsfaced"));
		int ballsDelivered = Integer.parseInt(request.getParameter("ballsbowled"));
		int bestWickets = Integer.parseInt(request.getParameter("highestwickets"));

		try {
			con = CricketDBConnection.getCricketDbConnection();
			pst = con.prepareStatement("select * from cricketer_tbl where id= " + id);
			rs = pst.executeQuery();
			if (rs.next()) {
				if (rs.getInt("HIGHESTSCOREINODI") > totalScore) {
					score = rs.getInt("HIGHESTSCOREINODI");
				} else {
					score = totalScore;
				}
				if (rs.getInt("HIGHESTWICKETS") > bestWickets) {
					wickets = rs.getInt("HIGHESTWICKETS");
				} else {
					wickets = bestWickets;
				}
				String sql = "update cricketer_tbl set NOOFODIMATCHES=" + (rs.getInt("NOOFODIMATCHES") + 1)
						+ ",TOTALSCOREINODI=" + (rs.getInt("totalscoreinodi") + totalScore) + ", HIGHESTSCOREINODI= "
						+ score + ",NOOFBALLSFACED = " + (rs.getInt("NOOFBALLSFACED") + ballsFaced)
						+ ", NOOFBALSSBOWLED= " + (rs.getInt("NOOFBALSSBOWLED") + ballsDelivered) + ", HIGHESTWICKETS="
						+ wickets + ", TOTALWICKETS= " + (rs.getInt("TOTALWICKETS") + bestWickets) + " where id= " + id;
				pst = con.prepareStatement(sql);
				int update = pst.executeUpdate();
				System.out.println(update);
				response.sendRedirect("updatemsg.jsp?update=" + update);

			} else {
				response.sendRedirect("updateForm.html");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
