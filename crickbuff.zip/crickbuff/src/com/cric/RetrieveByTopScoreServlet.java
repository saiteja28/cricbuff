package com.cric;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cricbuff.db.CricketDBConnection;

/**
 * Servlet implementation class RetrieveCricketerInfoServlet
 */
@WebServlet("/RetrieveByTopScoreServlet")
public class RetrieveByTopScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			con = CricketDBConnection.getCricketDbConnection();
			pst = con.prepareStatement("select * from cricketer_tbl order by highestscoreinodi desc");
			rs = pst.executeQuery();
			request.setAttribute("rs", rs);
			request.getRequestDispatcher("displaybytopscore.jsp").forward(request, response);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
