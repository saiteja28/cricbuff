package com.cric;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cricbuff.db.CricketDBConnection;

/**
 * Servlet implementation class DeleteCricketerInfoServlet
 */
@WebServlet("/deleteServlet")
public class DeleteCricketerInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteCricketerInfoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");

		try {
			con = CricketDBConnection.getCricketDbConnection();
			pst = con.prepareStatement("select id,name,country from cricketer_tbl where id= ? and name=?");
			pst.setInt(1, id);
			pst.setString(2, name);
			rs = pst.executeQuery();
			if (rs.next()) {
				if (rs.getInt("id") == id) {
					pst = con.prepareStatement("delete from cricketer_tbl where id=? and name=?");
					pst.setInt(1, id);
					pst.setString(2, name);
					int delete = pst.executeUpdate();
					System.out.println(delete);
					response.sendRedirect("deletemsg.jsp?delete=" + delete + "&id=" + id + "&name=" + name);
				}
			} else {
				response.sendRedirect("deleteForm.html");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
